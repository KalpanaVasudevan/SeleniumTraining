package base;

import java.io.IOException;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import utils.ReadExcel;

public class ProjectSpecificMethods {
	
	public ChromeDriver driver;
	public String fileName;
	public String leadID;
	
	
	@BeforeMethod
	public void startApp() 
	{
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe"); //setting up browser and driver property
		
		driver = new ChromeDriver();  //create an object for ChromeDriver
		
		driver.get("http://leaftaps.com/opentaps/control/login"); //navigate to URL
		
		driver.manage().window().maximize(); //maximize the window
		
	}
	
	@AfterMethod
	public void closeBrowser() 
	{
		driver.close();
		
	}
	
	@DataProvider(name="fetchData")
	public String[][] sendData() throws IOException {
		
		return ReadExcel.readData(fileName);
		
	}
}
