package pages;

import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods{
	
	public LoginPage(ChromeDriver driver){
		
		this.driver=driver;	
	}
	
	
	//enterUserName
	public LoginPage enterUserName(String data) throws InterruptedException {
		
		driver.findElementById("username").sendKeys(data); //enter username
		Thread.sleep(1000);
		return this;
	}
	
	
	//enterPassWord
	public LoginPage enterPassWord(String data) {
		
		driver.findElementById("password").sendKeys(data);		
		return this;
	}
	
	
	//clickLoginButton
	public HomePage clickLoginButton() {
		
		driver.findElementByClassName("decorativeSubmit").click();
		return new HomePage(driver);
	}
	
	
}
