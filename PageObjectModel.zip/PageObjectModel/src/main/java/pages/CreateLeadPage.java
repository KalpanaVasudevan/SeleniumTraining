package pages;

import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;

public class CreateLeadPage extends ProjectSpecificMethods{
	
	public CreateLeadPage(ChromeDriver driver)
	{
		this.driver = driver;
	}
	
	//enterCompanyName
	public CreateLeadPage enterCompanyName(String data) {
		
		driver.findElementById("createLeadForm_companyName").sendKeys(data);
		
		return this;
	}
	
	//enterFirstName
	public CreateLeadPage enterFirstName(String data) {
		
		driver.findElementById("createLeadForm_firstName").sendKeys(data);
		return this;
	}
	
	//enterLastName
	public CreateLeadPage enterLastName(String data) {
		
		driver.findElementById("createLeadForm_lastName").sendKeys(data);
		return this;

	}
	
	//clickCreateLead
	public ViewLeadPage clickCreateLeadButton() {
		
		driver.findElementByClassName("smallSubmit").click();
		
		return new ViewLeadPage(driver);

	}
}
