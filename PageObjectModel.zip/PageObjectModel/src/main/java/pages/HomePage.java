package pages;

import static org.testng.Assert.assertTrue;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import base.ProjectSpecificMethods;


public class HomePage extends ProjectSpecificMethods  {
	
	public HomePage(ChromeDriver driver)
	{
		this.driver=driver;
	}
	
	public LoginPage clickLogout() {
		
		driver.findElementById("decorativeSubmit").click();
		
		return new LoginPage(driver);

	}
	public MyHomePage clickCrmSfaLink() {
		
		driver.findElementByXPath("//a[contains(text(),'CRM/SFA')]").click();
		
		return new MyHomePage(driver);
	}
	
	public HomePage verifyHomePage() {
		
		Assert.assertTrue(driver.findElementByXPath("//a[contains(text(),'CRM/SFA')]").isDisplayed());
		
		return this;
	}

}
