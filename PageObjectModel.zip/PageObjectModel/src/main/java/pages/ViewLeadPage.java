package pages;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import base.ProjectSpecificMethods;

public class ViewLeadPage extends ProjectSpecificMethods{
	
	public ViewLeadPage(ChromeDriver driver)
	{
		this.driver=driver;
	}
	
	
	public ViewLeadPage retrieveLeadID() {
		
		//Assert.assertTrue(driver.findElementById("viewLead_companyName_sp").isDisplayed());
		leadID =(driver.findElementById("viewLead_companyName_sp").getText()).replaceAll("[^0-9]", "");
		System.out.println("LeadID created is: "+leadID);
		
		return this;
	}
}
