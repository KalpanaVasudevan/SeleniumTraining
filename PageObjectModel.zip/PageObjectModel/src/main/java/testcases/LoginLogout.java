package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import base.ProjectSpecificMethods;
import pages.LoginPage;

public class LoginLogout extends ProjectSpecificMethods{

	
	@BeforeTest
	public void setData() {
		fileName = "TC001";

	}
	
	
	@Test(dataProvider="fetchData")
	public void runLoginLogout(String uName,String passWord) throws InterruptedException {
		
		new LoginPage(driver)
		.enterUserName(uName)
		.enterPassWord(passWord)
		.clickLoginButton();

	}

}
